package es.upm.behaviours;

import es.upm.AgentePerceptorTeclado;
import es.upm.util.EnvioModerador;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Comportamiento de arranque único: crea una ventana Swing para capturar mensajes
 * del usuario y enviarlos al moderador vía ACL.
 */
public class ComportamientoEntradaTeclado extends OneShotBehaviour {

    private JFrame ventana;

    public ComportamientoEntradaTeclado(Agent agente) {
        super(agente);
    }

    @Override
    public void action() {
        SwingUtilities.invokeLater(this::crearVentana);
    }

    private void crearVentana() {
        ventana = new JFrame("Entrada manual — Perceptor teclado");
        ventana.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        ventana.setLayout(new BorderLayout(8, 8));

        JLabel instrucciones = new JLabel(
                "<html>Formato: <b>Usuario: mensaje</b> — Ej: <i>Usuario1: Hola a todos</i></html>");
        instrucciones.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

        JTextField campo = new JTextField();
        campo.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JButton enviar = new JButton("Enviar al moderador");
        enviar.addActionListener(e -> enviarLinea(campo.getText(), campo));

        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    enviarLinea(campo.getText(), campo);
                }
            }
        });

        JPanel sur = new JPanel(new BorderLayout(6, 0));
        sur.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sur.add(campo, BorderLayout.CENTER);
        sur.add(enviar, BorderLayout.EAST);

        ventana.add(instrucciones, BorderLayout.NORTH);
        ventana.add(sur, BorderLayout.CENTER);
        ventana.pack();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);

        // --- CORRECCIÓN JAVA 11 ---
        if (myAgent instanceof AgentePerceptorTeclado) {
            AgentePerceptorTeclado perceptorTeclado = (AgentePerceptorTeclado) myAgent;
            perceptorTeclado.registrarVentana(ventana);
        }
        // ---------------------------

        System.out.println("[PERCEPTOR-TECLADO] Ventana de entrada manual lista.");
    }

    private void enviarLinea(String texto, JTextField campo) {
        String linea = texto == null ? "" : texto.trim();
        if (linea.isEmpty()) {
            return;
        }
        if (!linea.contains(":")) {
            linea = "Manual:" + linea;
        }

        boolean enviado = EnvioModerador.enviar(myAgent, linea);
        if (enviado) {
            System.out.println("[PERCEPTOR-TECLADO] Enviado → " + linea);
            campo.setText("");
        } else {
            JOptionPane.showMessageDialog(ventana,
                    "No se encontró el moderador en el DF. ¿Está arrancado el agente moderador?",
                    "Moderador no disponible",
                    JOptionPane.WARNING_MESSAGE);
        }
    }
}
